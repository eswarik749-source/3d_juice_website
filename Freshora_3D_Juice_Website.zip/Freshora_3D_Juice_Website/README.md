# FRESHORA — 3D-inspired Fruit Juice Website

A responsive, premium fruit-juice landing page. Your uploaded FRESHORA commercial is embedded as the **only video**, in the homepage hero section.

## Run it
1. Extract the ZIP.
2. Open the `Freshora_3D_Juice_Website` folder in VS Code.
3. Open `index.html` in a browser, or use the VS Code **Live Server** extension and click **Go Live**.

## Included
- `index.html` — full landing page
- `style.css` — responsive layout, motion, and 3D-inspired styling
- `script.js` — mobile navigation and scroll reveal
- `assets/freshora-hero.mp4` — your uploaded video

Product photography loads from Unsplash, so an internet connection is needed for those images and Google Fonts. The homepage hero video is local and included in the ZIP.
